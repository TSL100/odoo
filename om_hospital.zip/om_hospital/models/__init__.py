from . import patient
from . import appointment
from . import patient_tag
from . import odoo_playground
from . import res_config_settings
from . import operation
from . import groups
